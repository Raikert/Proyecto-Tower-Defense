#include <SFML/Graphics.hpp>
#include "windows.h"
#include <iostream>
#include <cstdlib>
using namespace sf;
using namespace std;

int main()
{
    RenderWindow window(VideoMode(900, 600), "TOWER DEFENSE");
    /*
    CircleShape circulo1(100.f);
    circulo1.setFillColor(Color::Green);
    float x,y;
    */
    Texture textura;
    if (!textura.loadFromFile("img/001.jpg")) return EXIT_FAILURE;
    Sprite sprite;
    sprite.setTexture(textura);
    CircleShape circulo1(100.f);
    float x,y;
    while (window.isOpen())
    {
        Event event;
        while (window.pollEvent(event))
        {
            if (event.type == Event::Closed)
                window.close();
        }
        window.clear();
        window.draw(sprite);
        window.draw(circulo1);
        if (circulo1.getPosition().x<600&&circulo1.getPosition().y<=0) {
        x=circulo1.getPosition().x+.1;
        circulo1.setPosition(x,circulo1.getPosition().y);
        }
        if (circulo1.getPosition().x>600&&circulo1.getPosition().y<400) {
        y=circulo1.getPosition().y+.1;
        circulo1.setPosition(circulo1.getPosition().x,y);
        }
        if (circulo1.getPosition().x>0&&circulo1.getPosition().y>400) {
        x=circulo1.getPosition().x-.1;
        circulo1.setPosition(x,circulo1.getPosition().y);
        }
        if (circulo1.getPosition().x<0&&circulo1.getPosition().y>0) {
        y=circulo1.getPosition().y-.1;
        circulo1.setPosition(circulo1.getPosition().x,y);
        }
        window.display();
    }
    /*
    cout<<x<<endl;
    cout<<y<<endl;
    */
    return 0;
}
