#include <SFML/Graphics.hpp>
#include "windows.h"
#include <iostream>
#include <cstdlib>
///para no poner sf::

using namespace sf;
using namespace std;

///funciones hibridas con objetos

void mov_obj_abajo(CircleShape *circulo,float velocidad_y)
{
    float y;
    y=circulo->getPosition().y+velocidad_y;
    circulo->setPosition(circulo->getPosition().x,y);
}

void mov_diagonal_izq_abajo(CircleShape *circulo,float velocidad_x, float velocidad_y)
{
    float x,y;
    x=circulo->getPosition().x-velocidad_x;
    y=circulo->getPosition().y+velocidad_y;
    circulo->setPosition(x,y);
}

void mov_obj_derecha(CircleShape *circulo,float velocidad_x)
{
    float x;
    x=circulo->getPosition().x+velocidad_x;
    circulo->setPosition(x,circulo->getPosition().y);
}

void mov_diagonal_der_arriba (CircleShape *circulo,float velocidad_x,float velocidad_y)
{
    float x,y;
    x=circulo->getPosition().x+velocidad_x;
    y=circulo->getPosition().y-velocidad_y;
    circulo->setPosition(x,y);
}

void mov_derecha(CircleShape *circulo,float velocidad_x)
{
    float x;
    x=circulo->getPosition().x+velocidad_x;
    circulo->setPosition(x,circulo->getPosition().y);
}

void mov_diagonal_der_abajo(CircleShape *circulo,float velocidad_x,float velocidad_y)
{
    float x,y;
    x=circulo->getPosition().x+velocidad_x;
    y=circulo->getPosition().y+velocidad_y;
    circulo->setPosition(x,y);
}

int main()
{
    ///carga del mundo

    RenderWindow window(VideoMode(800, 600), "TOWER DEFENSE");
    Texture textura,texturacirculo,texturamenu;
    if (!textura.loadFromFile("img/007.png"))
        return EXIT_FAILURE;
    if (!texturacirculo.loadFromFile("img/004.jpg"))
        return EXIT_FAILURE;
    if (!texturamenu.loadFromFile("img/006.jpg"))
        return EXIT_FAILURE;
    Sprite sprite,sprite1;
    sprite.setTexture(textura);
    sprite1.setTexture(texturamenu);
    CircleShape circulo1(50.f);
    circulo1.setTexture(&texturacirculo);
    float opacidad=0.4,opacidad1=1; ///transparencia del objeto 255=100% porciento
    circulo1.setFillColor(Color(255,255,255,opacidad));
    circulo1.setPosition(290,0);
    float x,y;
    int estado=-1;
    while (window.isOpen())
    {
        Event event;
        while (window.pollEvent(event))
        {
            if (event.type == Event::Closed)
                window.close();
        }
        window.clear();
        if (estado!=-1) {
        window.draw(sprite);
        window.draw(circulo1);
        }
        ///Peque�a maquina de estados
        switch (estado)
        {
    case -1:
        sprite1.setColor(Color(255,255,255,opacidad1));
        window.draw(sprite1);
        if (opacidad1<255) {
        opacidad1++;
        } else {
        if (Mouse::isButtonPressed(Mouse::Left)) {
        if (Mouse::getPosition(window).x>=281&&Mouse::getPosition(window).x<=469&&Mouse::getPosition(window).y>=316&&Mouse::getPosition(window).y<=353)
        estado=0;
        if ()
        }
        }
        break;
        case 0:
            if (circulo1.getPosition().y<171)
            {
                if(opacidad<255)
                {
                    opacidad+=0.4;
                    circulo1.setFillColor(Color(255,255,255,opacidad));
                }
                mov_obj_abajo(&circulo1,0.1);

            }
            else
                estado=1;
            break;
        case 1:
            if (circulo1.getPosition().y>171&&circulo1.getPosition().x>35)
            {
                mov_diagonal_izq_abajo(&circulo1,0.1,0.038);

            }
            else
                estado=2;
            break;
        case 2:
            if (circulo1.getPosition().x<35&&circulo1.getPosition().y<429)
            {
                mov_obj_abajo(&circulo1,0.1);

            }
            else
                estado=10;
            break;
        case 10:
            if (circulo1.getPosition().y>429&&circulo1.getPosition().y<500)
            {
                mov_diagonal_der_abajo(&circulo1,0.1,0.1);
            }
            else
                estado=3;
            break;
        case 3:
            if (circulo1.getPosition().y>500&&circulo1.getPosition().x<292)
            {
                mov_obj_derecha(&circulo1,0.1);
            }
            else
                estado=4;
            break;
            break;
        case 4:
            if (circulo1.getPosition().x>292&&circulo1.getPosition().x<570)
            {
                mov_diagonal_der_arriba(&circulo1,0.1,0.1);
            }
            else
                estado=5;
            break;
        case 5:
            if(circulo1.getPosition().x<637)
            {
                mov_derecha(&circulo1,0.1);
            }
            else
                estado=6;
            break;
        case 6:
            if (circulo1.getPosition().x>637&&circulo1.getPosition().x<700)
            {
                mov_derecha(&circulo1,0.1);
                if(opacidad>0)
                {
                    opacidad-=0.4;
                    circulo1.setFillColor(Color(255,255,255,opacidad));
                }
            }
            else
            {
                circulo1.setPosition(290,0);
                estado=0;
            }
            break;
        }
        ///Pruebas iniciales con circulos
        /*
        window.draw(circulo1);
        if (circulo1.getPosition().x<600&&circulo1.getPosition().y<=0) {
        x=circulo1.getPosition().x+.1;
        circulo1.setPosition(x,circulo1.getPosition().y);
        }
        if (circulo1.getPosition().x>600&&circulo1.getPosition().y<400) {
        y=circulo1.getPosition().y+.1;
        circulo1.setPosition(circulo1.getPosition().x,y);
        }
        if (circulo1.getPosition().x>0&&circulo1.getPosition().y>400) {
        x=circulo1.getPosition().x-.1;
        circulo1.setPosition(x,circulo1.getPosition().y);
        }
        if (circulo1.getPosition().x<0&&circulo1.getPosition().y>0) {
        y=circulo1.getPosition().y-.1;
        circulo1.setPosition(circulo1.getPosition().x,y);
        }
        */
        window.display();
    }

    ///debug de variables en la terminal-no darle bola al warning
    cout<<x<<endl;
    cout<<y<<endl;
    system("pause");
    return 0;
}
