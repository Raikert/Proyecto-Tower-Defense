#include <SFML/Graphics.hpp>
#include "windows.h"
#include <iostream>
#include <cstdlib>
using namespace sf;
using namespace std;

void mov_obj_abajo(CircleShape *circulo,int limite_de_pixeles,float velocidad) {
float y;
if (circulo->getPosition().y<limite_de_pixeles) {
y=circulo->getPosition().y+velocidad;
circulo->setPosition(circulo->getPosition().x,y);
}
}

int main()
{
    RenderWindow window(VideoMode(1680, 1050), "TOWER DEFENSE");
    /*
    CircleShape circulo1(100.f);
    circulo1.setFillColor(Color::Green);
    float x,y;
    */
    Texture textura;
    if (!textura.loadFromFile("img/003.jpg"))
        return EXIT_FAILURE;
    Sprite sprite;
    sprite.setTexture(textura);
    CircleShape circulo1(50.f);
    circulo1.setFillColor(Color::Red);
    circulo1.setPosition(654,0);
    float x,y;
    while (window.isOpen())
    {
        Event event;
        while (window.pollEvent(event))
        {
            if (event.type == Event::Closed)
                window.close();
        }
        window.clear();
        window.draw(sprite);
        window.draw(circulo1);
        mov_obj_abajo(&circulo1,320,0.1);
        /*
        if (circulo1.getPosition().y<320)
        {
            y=circulo1.getPosition().y+.1f;
            circulo1.setPosition(circulo1.getPosition().x,y);
        }
        */
        if (circulo1.getPosition().y>320&&circulo1.getPosition().x>120)
        {
            x=circulo1.getPosition().x-.1f;
            y=circulo1.getPosition().y+.038f;
            circulo1.setPosition(x,y);
        }
        if (circulo1.getPosition().x<120&&circulo1.getPosition().y<881)
        {
            y=circulo1.getPosition().y+.1f;
            circulo1.setPosition(circulo1.getPosition().x,y);
        }
        if (circulo1.getPosition().y>881&&circulo1.getPosition().x<620) {
        x=circulo1.getPosition().x+.1f;
        circulo1.setPosition(x,circulo1.getPosition().y);
        }
        /*
        window.draw(circulo1);
        if (circulo1.getPosition().x<600&&circulo1.getPosition().y<=0) {
        x=circulo1.getPosition().x+.1;
        circulo1.setPosition(x,circulo1.getPosition().y);
        }
        if (circulo1.getPosition().x>600&&circulo1.getPosition().y<400) {
        y=circulo1.getPosition().y+.1;
        circulo1.setPosition(circulo1.getPosition().x,y);
        }
        if (circulo1.getPosition().x>0&&circulo1.getPosition().y>400) {
        x=circulo1.getPosition().x-.1;
        circulo1.setPosition(x,circulo1.getPosition().y);
        }
        if (circulo1.getPosition().x<0&&circulo1.getPosition().y>0) {
        y=circulo1.getPosition().y-.1;
        circulo1.setPosition(circulo1.getPosition().x,y);
        }
        */
        window.display();
    }
    /*
    cout<<x<<endl;
    cout<<y<<endl;
    */
    return 0;
}
